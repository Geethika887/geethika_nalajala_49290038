package com.cg.staff;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StaffMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
