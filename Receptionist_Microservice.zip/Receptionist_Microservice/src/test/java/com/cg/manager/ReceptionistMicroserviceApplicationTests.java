package com.cg.manager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReceptionistMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
